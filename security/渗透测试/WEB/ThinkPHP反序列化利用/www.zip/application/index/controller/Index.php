<?php
namespace app\index\controller;

class Index
{
    public function index()
    {
		return "<a href='www.zip'>download code</a>";
    }

    public function hello()
    {
        unserialize($_POST['str']);
    }
}
